export class admin {
    constructor(
       public username:string,
       public password:string,  
    ){}
}
