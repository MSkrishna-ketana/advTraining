export class policies {
    constructor(
       public policyName:string,
       public amount:string,
       public tenureInYears:string,
       public category:string,
    ){}
}
